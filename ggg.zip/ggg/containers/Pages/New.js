import React, { Component } from 'react'
import Forms from './Forms'


export default class NewPageContainer extends Component {
  render() {
    return (
      <Forms />
    )
  }
}
