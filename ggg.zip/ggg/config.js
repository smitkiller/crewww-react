module.exports = {
  host: 'crewww-c780d.firebaseapp.com',
  apiPort: 3001,
  serverPort: 3000,
  clientPort: 3002
}
