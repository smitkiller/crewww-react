//import config from '../config'
//const API_ROOT = `http://${config.host}:${config.apiPort}/api/v1`
//const API_ROOT ='https://console.firebase.google.com/project/crewww-c780d/database/data'
const API_ROOT = 'https://crewww-c780d.firebaseio.com'

//export const PAGES_ENDPOINT = `${API_ROOT}/pages`
//export const LOGIN_ENDPOINT = `${API_ROOT}/users`
//export const DATAS_ENDPOINT = `${API_ROOT}/datas`


export const PAGES_ENDPOINT = `${API_ROOT}/pages.json`
export const LOGIN_ENDPOINT = `${API_ROOT}/users.json`
export const DATAS_ENDPOINT = `${API_ROOT}/datas.json`
